<?php
$title = "Editar";
include 'header.php';
include 'footer.php';

?>