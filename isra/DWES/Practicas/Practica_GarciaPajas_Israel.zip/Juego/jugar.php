<?php
$title = "Jugar";
include 'header.php';
include 'footer.php';
?>