<?php
$title = "Perfil";
include 'header.php';
include 'footer.php';

?>